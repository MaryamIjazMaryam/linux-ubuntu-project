# Linux & Ubuntu WSL Practice Project

**Author:** Maryam Ijaz  
**Platform:** Ubuntu on WSL2 (Windows 11)  
**Level:** Beginner / Practice Project

## 1. Project Overview

This repository documents my hands-on Linux and Ubuntu practice while preparing for DevOps-related learning. The project focuses on working in a Linux terminal, creating and executing Bash scripts, managing executable permissions, checking packages, using basic Git commands, and building a system-monitoring script.

> **Accuracy note:** The terminal images in this package are **recreated terminal-style captures based only on the command/output transcript supplied for this project**. They are not original screenshots taken from the user's Windows screen.

## 2. Verified Environment

- Windows 11
- WSL2
- Ubuntu 26.04.1 LTS
- Linux username: `laptopmaryam`
- WSL kernel: `6.18.33.2-microsoft-standard-WSL2`
- Home directory: `/home/laptopmaryam`

## 3. Skills Demonstrated

### Linux / WSL
- `pwd` — show the current directory
- `ls` — list files and folders
- `cd` — move between directories
- Working from the Linux home directory

### File and Script Work
- Creating/editing scripts with `cat >`
- Editing files with `nano`
- Making scripts executable with `chmod +x`
- Running scripts with `./script-name.sh`

### Package Management
- Using Ubuntu's `apt` package manager
- Checking/installing Git with `sudo apt install git`

### Git Basics
- Attempting to clone a GitHub repository with `git clone`
- Understanding the error produced when the destination directory already exists and is not empty

### Bash System Monitoring
The monitoring script uses:
- `date`
- `cal`
- `uptime`
- `free -h`
- `df -h`
- `top -bn1 | grep "load average"`
- `ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head -n 6`
- `who`

## 4. Main Project: Linux System Monitoring Tool

The Bash script collects basic system information and displays it as a readable terminal report.

### What it reports
1. Current date and time
2. Calendar
3. System uptime
4. Memory usage
5. Disk usage
6. CPU load
7. Top CPU-consuming processes
8. Logged-in users

## 5. Bash Script

```bash
#!/bin/bash

# Color Codes
RED=\'\033[0;31m\'
GREEN=\'\033[0;32m\'
YELLOW=\'\033[1;33m\'
BLUE=\'\033[0;34m\'
CYAN=\'\033[0;36m\'
MAGENTA=\'\033[0;35m\'
NC=\'\033[0m\'

echo -e "${MAGENTA}==========================================${NC}"
echo -e " 🚀 Linux System Monitoring Tool"
echo -e "${MAGENTA}==========================================${NC}"
echo ""
echo -e "${CYAN}📅 Current Date & Time:${NC}"
date
echo ""
echo -e "${CYAN}🗓️ Calendar:${NC}"
cal
echo ""
echo -e "${GREEN}⏱️ System Uptime:${NC}"
uptime
echo ""
echo -e "${GREEN}💾 Memory Usage:${NC}"
free -h
echo ""
echo -e "${YELLOW}💿 Disk Usage:${NC}"
df -h
echo ""
echo -e "${BLUE}⚙️ CPU Load:${NC}"
top -bn1 | grep "load average"
echo ""
echo -e "${RED}🔥 Top 5 CPU Consuming Processes:${NC}"
ps -eo pid,ppid,cmd,%mem,%cpu --sort=-%cpu | head -n 6
echo ""
echo -e "${CYAN}👤 Logged in Users:${NC}"
who
echo ""
echo -e "${MAGENTA}==========================================${NC}"
echo -e "          ✅ End of Report"
echo -e "${MAGENTA}==========================================${NC}"
```

## 6. How to Run

```bash
chmod +x colour_monitoring.sh
./colour_monitoring.sh
```

The simpler monitoring script was also executed as:

```bash
chmod +x system_monitor.sh
./system_monitor.sh
```

## 7. Screens / Terminal Captures

### Navigation and Setup
![Navigation and setup](assets/01_navigation_and_setup.png)

### System Monitor Output
![System monitor output](assets/02_system_monitor_output.png)

### Monitoring Script
![Monitoring script](assets/03_colour_monitoring_script.png)

### Git and Troubleshooting
![Git and troubleshooting](assets/04_git_and_errors.png)

## 8. Troubleshooting Evidence

During practice, several normal beginner errors were encountered and corrected or documented:

| Issue | What happened |
|---|---|
| `cal: command not found` | The calendar command was initially unavailable; it later worked after the required calendar package was installed. |
| Wrong script filename | `./system_monitoring.sh` returned “No such file or directory”; the existing `system_monitor.sh` was then executed successfully. |
| Existing Git destination | `git clone` reported that `Ex280-Openshift` already existed and was not empty. |
| Accidental control character | A control character was accidentally inserted while creating the colored script and was reported at line 106. |

## 9. Project Scope

This README intentionally documents only the Linux/Bash/Git work that is directly supported by the supplied terminal transcript. Other folders visible in the home-directory listing are **not** treated as completed project modules unless their contents were explicitly demonstrated.

## 10. Learning Outcome

This practice strengthened beginner Linux skills needed for DevOps learning: navigating the terminal, handling scripts, setting executable permissions, using Ubuntu package management, understanding basic Git workflow, and monitoring system resources from Bash.

## 11. Author

**Maryam Ijaz**  
BS Software Engineering Student
